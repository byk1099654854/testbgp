#!/bin/bash
 indent -npro -gnu -i4 -ts4 -sob -l200 -ss -bl -bli 0 -npsl $1
